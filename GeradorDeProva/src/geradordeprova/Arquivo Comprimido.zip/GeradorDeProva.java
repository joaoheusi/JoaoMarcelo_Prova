/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geradordeprova;
import java.util.Scanner;


/**
 *
 * @author joaomheusi
 */
public class GeradorDeProva {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        int auxTamanho= 0;
        String[] opcoesQuestoes = new String[5];

        
        //pede quantidades, peso,
        System.out.println("Digite a disciplina da prova:");
        Prova p1 = new Prova(s.nextLine());
        System.out.println("Digite a data da prova:");
        p1.setData(s.nextLine());
        System.out.println("Digite o local da prova:");
        p1.setLocal(s.nextLine());
        System.out.println("Digite o peso da prova:");
        p1.setPeso(Integer.parseInt(s.nextLine()));
        
        System.out.println("Digite a quantidade de questões discursivas:");
        auxTamanho = Integer.parseInt(s.nextLine());
        Discursiva[] disc = new Discursiva[auxTamanho];
        for (int i = 0; i < disc.length; i++) {
            disc[i] = new Discursiva();
            System.out.println("Digite a pergunta da questão:");
            disc[i].setPergunta(s.nextLine());
            System.out.println("Digite o critério para correção da questão discursiva:");
            disc[i].setCriteriosCorrecao(s.nextLine());
        }
        p1.setQuestoesDiscursivas(disc);
        System.out.println("Digite a quantidade de questoes objetivas:");
        auxTamanho = Integer.parseInt(s.nextLine());
        Objetiva[] obj = new Objetiva[auxTamanho];
        for (int i = 0; i < obj.length; i++) {
            obj[i] = new Objetiva();
            System.out.println("Digite a pergunta da questão:");
            obj[i].setPergunta(s.nextLine());
            System.out.println("Digite as opções para a questão discursiva:");
                System.out.println("Opção A:");
                opcoesQuestoes[0] = s.nextLine();
                System.out.println("Opção B:");
                opcoesQuestoes[1] = s.nextLine();
                System.out.println("Opção C:");
                opcoesQuestoes[2] = s.nextLine();
                System.out.println("Opção D:");
                opcoesQuestoes[3] = s.nextLine();
                System.out.println("Opção E:");
                opcoesQuestoes[4] = s.nextLine();
                obj[i].setOpcoes(opcoesQuestoes);
                System.out.println("Digite qual a opção correta(0...4):");
                obj[i].setRespostaCorreta(Integer.parseInt(s.nextLine()));
                
        }
        p1.setQuestoesObjetivas(obj);
        
        
   
    }
    
    
    
}
